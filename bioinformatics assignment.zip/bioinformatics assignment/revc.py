
def reverse_complement(dna_string):
    reversed_dna = dna_string[::-1]
    complement = {'A': 'T', 'T': 'A', 'C': 'G', 'G': 'C'}
    reverse_complement_dna = ''.join(complement[base] for base in reversed_dna)
    return reverse_complement_dna
sample_dna = "AAAACCCGGT"
print(reverse_complement(sample_dna))  