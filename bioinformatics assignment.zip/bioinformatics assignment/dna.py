
dna_string = "AGCTTTTCATTCTGACTGCAACGGGCAATATGTCTCTGTGTGGATTAAAAAAAGAGTGTCTGATAGCAGC"

dna_string.count('A') 
dna_string.count('C')    
dna_string.count('T')  
dna_string.count('G')

print(dna_string.count('A'),dna_string.count('C'),dna_string.count('G'),dna_string.count('T'))
