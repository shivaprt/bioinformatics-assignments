dna_string=('GATGGAACTTGACTACGTAAATT')
rna_string=(dna_string.replace('T','U'))
print(rna_string)