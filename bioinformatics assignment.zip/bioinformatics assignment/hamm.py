def hamming_distance(s, t):
    
    mismatches = 0
    
    for i in range(len(s)):
        
        if s[i] != t[i]:
            mismatches += 1  
    
    return mismatches


s = "GAGCCTACTAACGGGAT"
t = "CATCGTAATGACGGCCT"


print(hamming_distance(s, t))  