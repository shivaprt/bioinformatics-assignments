def parse_fasta(data):
    sequences = {}
    current_id = None

    for line in data.splitlines():
        if line.startswith('>'):  
            current_id = line[1:]  
            sequences[current_id] = "" 
        else:
            sequences[current_id] += line.strip()  
    
    return sequences

def calculate_gc_content(dna_sequence):
    gc_count = dna_sequence.count('G') + dna_sequence.count('C')
    total_length = len(dna_sequence)
    gc_content = (gc_count / total_length) * 100
    return gc_content

def highest_gc_content(data):
    sequences = parse_fasta(data)  
    max_gc_id = ""
    max_gc_content = 0.0

    for seq_id, dna_sequence in sequences.items():
        gc_content = calculate_gc_content(dna_sequence)
        if gc_content > max_gc_content: 
            max_gc_content = gc_content
            max_gc_id = seq_id

    return max_gc_id, max_gc_content


data = """>Rosalind_6404
CCTGCGGAAGATCGGCACTAGAATAGCCAGAACCGTTTCTCTGAGGCTTCCGGCCTTCCC
TCCCACTAATAATTCTGAGG
>Rosalind_5959
CCATCGGTAGCGCATCCTTAGTCCAATTAAGTCCCTATCCAGGCGCTCCGCCGAAGGTCT
ATATCCATTTGTCAGCAGACACGC
>Rosalind_0808
CCACCCTCGTGGTATGGCTAGGCATTCAGGAACCGGAGAACGCTTCAGACCAGCCCGGAC
TGGGAACCTGCGGGCAGTAGGTGGAAT"""


highest_id, highest_gc = highest_gc_content(data)
print(highest_id)
print(highest_gc)
