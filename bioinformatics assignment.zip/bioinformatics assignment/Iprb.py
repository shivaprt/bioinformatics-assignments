def dominant_phenotype_probability(k, m, n):
    total = k + m + n

    total_pairs = total * (total - 1) / 2
    
    prob_dominant = (
        k * (k - 1) / 2 * 1 +         
        k * m * 1 +                    
        k * n * 1 +                   
        m * (m - 1) / 2 * 0.75 +       
        m * n * 0.5                    
    )
    
    probability = prob_dominant / total_pairs
    return probability


k, m, n = 2, 2, 2
print(dominant_phenotype_probability(k, m, n)) 