def total_rabbit_pairs(n, k):
    
    rabbit_pairs = [0] * (n + 1) 
    
    
    rabbit_pairs[1] = 1  
    rabbit_pairs[2] = 1  
    for month in range(3, n + 1):
        rabbit_pairs[month] = rabbit_pairs[month - 1] + (rabbit_pairs[month - 2] * k)
    return rabbit_pairs[n]


n = 5  
k = 3  

print(total_rabbit_pairs(n, k))  
